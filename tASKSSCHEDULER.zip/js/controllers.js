angular.module('app.controllers', [])
  
.controller('page2Ctrl', function($scope) {

})
   
.controller('registerHereCtrl', function($scope) {

})
 